#Initializes All Dictionaries and Lists.
def InitalizingThings():
    try:
        NodeDict = {}
        IPDict = {}
        MessageDict = {}
        IPList = []
        FirstOctetDict = {}
        with open("Applog.txt","r") as myFile:
            mylinelist =myFile.readlines()
            for line in mylinelist:
                myline = line.split(" - ")
                NodeDict[myline[0]] = NodeDict.get(myline[0],0) + 1
                
                IPDict[myline[1]] = IPDict.get(myline[1],0) + 1
            
                MessageDict[myline[2]] = MessageDict.get(myline[2],0) + 1
            
                IPList.append(myline[1])
            for item in IPList:
                item = str(item)
                NewIPList = item.split(".")
                FirstOctetDict[NewIPList[0]] = FirstOctetDict.get(NewIPList[0],0) + 1
        return(NodeDict,IPDict,MessageDict,IPList,FirstOctetDict)
    except Exception as ex: 
        with open("finalProjExceptions.txt", "a") as mylogfile:
            mylogfile.write(str(ex))

#How many events does each “node” have in the applog.txt file?
def Challenge1():
    try:
        Data = InitalizingThings()
        nodeItems = Data[0].items()
        for key, value in nodeItems:
            print(key + ":" + str(value)) 
    except Exception as ex: 
        with open("finalProjExceptions.txt", "a") as mylogfile:
            mylogfile.write(str(ex))
            
#Print the IP addresses within applog.txt that have a value for the second or third octet that is equivalent to the octet value entered by the user.
def Challenge2():
    try:
        count = 0
        Data = InitalizingThings()
        IPChoice = input("Choose an IP address octet value:")
        #IPChoice = int(IPChoice) 
        for item in Data[3]:
            NewIPList = item.split(".")
            if IPChoice == NewIPList[1] or IPChoice == NewIPList[2]:
                print(item)
                count = count + 1
        print(count)
    except Exception as ex: 
        with open("finalProjExceptions.txt", "a") as mylogfile:
            mylogfile.write(str(ex))
            
#Display the count for each unique first octet value.
def Challenge3():
    try:
        Data = InitalizingThings()
        octetItems = Data[4].items()
        for key, value in octetItems:
            print(key + ":" + str(value))
    except Exception as ex: 
        with open("finalProjExceptions.txt", "a") as mylogfile:
            mylogfile.write(str(ex))
            
#Display the unique list of messages found in the file
def Challenge4():
    try:
        Data = InitalizingThings()
        MessageItems = Data[2].items()
        for key, value in MessageItems:
            print(key)
    except Exception as ex: 
        with open("finalProjExceptions.txt", "a") as mylogfile:
            mylogfile.write(str(ex))