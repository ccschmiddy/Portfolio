import FinalFunctions

while True:
    print("-------------------------------------------------")
    print("Challenge 1\n")
    print("Challenge 2\n")
    print("Challenge 3\n")
    print("Challenge 4\n")
    print("-------------------------------------------------")
    Input = input("What Challenge # would you like?\n")
    print("-------------------------------------------------")
    if Input == "1":
        FinalFunctions.Challenge1()
    if Input == "2":
        FinalFunctions.Challenge2()
    if Input == "3":
        FinalFunctions.Challenge3()
    if Input == "4":
        FinalFunctions.Challenge4()

    
    
